-- AlterTable
ALTER TABLE "Transaction" ADD COLUMN     "isSales" TEXT NOT NULL DEFAULT 'N';
