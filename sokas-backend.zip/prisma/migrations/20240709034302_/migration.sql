-- AlterTable
ALTER TABLE "Cart" ADD COLUMN     "isSales" TEXT DEFAULT 'N';
