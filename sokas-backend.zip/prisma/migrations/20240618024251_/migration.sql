-- AlterTable
ALTER TABLE "TransactionDetail" ADD COLUMN     "discount" INTEGER;
