/*
  Warnings:

  - You are about to drop the column `master_area_id` on the `Area` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Area" DROP COLUMN "master_area_id";
