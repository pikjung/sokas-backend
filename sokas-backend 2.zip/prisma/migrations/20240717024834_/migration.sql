-- AlterTable
ALTER TABLE "Transaction" ADD COLUMN     "noted" TEXT;
