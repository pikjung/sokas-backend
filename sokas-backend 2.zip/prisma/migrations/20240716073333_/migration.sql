-- AlterTable
ALTER TABLE "Transaction" ADD COLUMN     "isCancel" TEXT NOT NULL DEFAULT 'N';
