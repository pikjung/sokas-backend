-- AlterTable
ALTER TABLE "Store" ADD COLUMN     "no_telp" TEXT;
